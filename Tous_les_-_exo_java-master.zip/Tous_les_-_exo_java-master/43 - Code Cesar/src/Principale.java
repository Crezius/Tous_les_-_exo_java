
public class Principale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI gui = new GUI(500, 500, true, "J'aime le chocolat");
	}

}
